<?php 
    include 'includes/headlink.php';
    include 'includes/header.php';
    include 'controller/Usercontroller.php';
?>
<div class="topdivmargin">
<div  class="padding">
    <div class="title">
        <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2; margin-bottom:35px;">Update Details</h1>
        <?php
        if(isset($_GET["update"]) && isset($_GET["id"]))
        {
            $id = $_GET["id"];
           // echo $id; 
            $obj = new Usercontroller();
            $row = $obj->displaySliderUpdate($id);
            // print_r($row);
           $filename = $row['img'];
        ?>
            <div style="margin:auto;" class="container">
                <div class="card">
                    <div class="card-body">
                        <form action="controller/Usercontroller.php"  method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">


                           <input type='file' name="img" id="img" accept=".png, .jpg, .jpeg"  />
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="url" placeholder="TITLE" name="title" value="<?php echo $row['title']?>">
                        </div>
                        <div class="mb-3">
                            <label for="url" class="form-label">Url</label>
                            <input type="text" class="form-control" id="url" placeholder="URL" name="url"  value="<?php echo $row['url']?>">
                        </div>
                        <div class="mb-3">
                            <label for="imgdescription" class="form-label">Description</label>
                            <textarea class="form-control" id="imgdescription" rows="3" name="description">
                            <?php echo $row['description']?>
                        </textarea>
                        </div>
                        <div class="modal-footer">
                            <!-- <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Delete</button> -->
                            <button type="submit" name="update" class="btn btn-info text-white">Update</button>
                        </div>
                        </form> 

                    </div>   
                </div>
            </div>      

        <?php
          
        }
        ?>
    </div>
</div>
</div>