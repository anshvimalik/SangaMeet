<?php 
    include 'includes/headlink.php';
    include 'includes/header.php';
?>
<div class="topdivmargin">
<div  class="padding">
    <div class="title">
        <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Settings</h1>
    </div>
</div>
</div>