<?php 
                echo "<div class='pagination'>";
                for ($i = 1; $i <= $totalpages; $i++) {
                    echo "<a href='usersprofile.php?page=$i'>$i</a>";
                }
                echo "</div>"; ?>
            <table class="table table-bordered users-table">
                <thead> 
                    <tr>
                        <th scope="col">Username</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Status</th>
                        <th scope="col">Option</th>
                        <!-- <th scope="col"></th> -->
                        <!-- <th scope="col"></th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach($rows as $row)
                    {
                       
                        echo'<tr>';
                        echo'<td>'.$row['name'].'</td>';
                        echo'<td>'.$row['email'].'</td>';
                        echo'<td>'.$row['status'].'</td>';
                        echo'<td>'.$row['users_id'].'</td>';
                        echo'<td>'
                    ?>
                        <div class="btn-group">
                        <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Choose
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="controller/Usercontroller.php?id=<?php echo $row['users_id'];?>">Approved</a></li>
                            <li><a class="dropdown-item" href="#">Rejected</a></li>
                        </ul>
                        </div>
                    <?php
                        '</td>';
                        echo'</tr>';
                    }
                    ?>

                </tbody>
            </table>  
            class="table table-bordered users-table"