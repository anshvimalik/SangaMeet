$(document).ready(function(){
	// console.log("submit");
	$("#submit").on('click', function(e){
	// $("button[name='submit']").on('click',function(){
		console.log("yes");
		e.preventDefault();
        var form = new FormData();
        // form.append('img', file);
        form.append('name', $('.name').val());
        form.append('email', $('.email').val());
        form.append('password', $('.password').val());
        form.append('phone', $('.phone').val());
        form.append('gender', $('.gender').val());
        form.append('house', $('.house').val());
        form.append('street', $('.street').val());
        form.append('city', $('.city').val());
        form.append('state', $('.state').val());
        form.append('pincode', $('.pincode').val());
        form.append('type', $('.type').val());
        form.append('country', $('.country').val());
		console.log(form); 
        $.ajax({
			url:'controller/Usercontroller.php',
			type:'POST',
            cache: false,
                contentType: false,
                processData: false,
			data:{ form },
			success:function(response){
				 console.log('response',response);
                // var parse_data = JSON.parse(response);
				// console.log(parse_data);
				// $('#response').html(parse_data.message);
				
			},
		});
         
		
	});
});
</script>




    <div class="body2">
        <section class="register add">
            <header>Become our member</header>
            <form class="form" id="register" enctype="multipart/form-data">
                <!-- action="controller/Usercontroller.php" method="POST" -->
                <div class="column">
                    <div class="input-box">
                        <label class="form-label">Image</label>
                        <input type="file" placeholder="Enter phone number" name="img" class="form-control" />
                    </div>
                    <div class="input-box">
                        <label>Name</label>
                        <input type="text" placeholder="Enter name" name="name" class="name" />
                    </div>
                </div>

                <div class="input-box">
                    <label>Email</label>
                    <input type="email" placeholder="Enter email address" name="email" class="email" />
                </div>

                <div class="column">
                    <div class="input-box">
                        <label>Phone Number</label>
                        <input type="text" placeholder="Enter phone number" name="phone" class="phone" />
                    </div>
                    <div class="input-box">
                        <label>Password</label>
                        <input type="password" placeholder="Enter password" name="password" class="password" />
                    </div>
                </div>

                <div class="gender-box">
                    <h3>Gender</h3>
                    <div class="gender-option">
                        <div class="gender">
                            <input type="radio" name="gender" id="check-male" class="gender" name="gender" value="male" checked>
                                <label for="check-male">Male</label>
                        </div>
                        <div class="gender">
                            <input type="radio" name="gender" id="check-female" class="gender" name="gender" value="female" >
                                <label for="check-female">Female</label>
                        </div>
                    </div>
                </div>

                <div class="column">
                    <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                    $i = 0;
                   foreach($addresses as $key=>$address){
                        $type = "address[$i][type]";
                ?>
                    <div class="input-box">
                        <label><?php echo $address?></label>
                        <input type="hidden" class="type" name="<?php echo $type;?>" value="<?php echo $key; ?>">
                            <input type="text" placeholder="Enter house no " class="house" name="address[<?php echo $i ?>][house]" />
                            <input type="text" placeholder="Enter street address" class="street" name="address[<?php echo $i ?>][street]" />
                            <input type="text" placeholder="Enter your city" class="city" name="address[<?php echo $i ?>][city]" />
                            <input type="text" placeholder="Enter your state" class="state" name="address[<?php echo $i ?>][state] " />
                            <input type="text" placeholder="Enter pincode " class="pincode" name="address[<?php echo $i ?>][pincode]"  >
                                <input type="text" placeholder="Enter your country " class="country" name="address[<?php echo $i ?>][country]" />
                            </div>
                            <?php
                            $i++;
                   }
                ?>
                    </div>

                    <div class="input-box">
                        <label>Social media (if any)</label>
                        <input type="text" placeholder="Enter Instagram Profile " class="insta" name="instagram" />
                        <input type="text" placeholder="Enter Facebook Profile" class="facebook" name="facebook" />
                        <input type="text" placeholder="Enter your Twitter Profile " class="twitter" name="twitter" />
                    </div>

                    <div style="text-align:center; margin-top:35px;">
                        <button type="submit" name="submit" id="submit" class="btn btn-block btn-info button" >Become a member</button>
                    </div>
            </form>

            <div id="response"></div>
        </section>
    </div>




    
<?php
include "includes/headlinks.php";
include "layout/header.php";
?>
<div class="body2">
    <section class="register add">
        <header>Become our member</header>
        <form  class="form" id="register"  enctype="multipart/form-data">
              <!-- action="controller/Usercontroller.php" method="POST" -->
		    <div class="column">
                <div class="input-box">
                    <label class="form-label">Image</label>
                    <input type="file" placeholder="Enter phone number"  name="img" class="form-control" />
                </div>
                <div class="input-box">
                    <label>Name</label>
                    <input type="text" placeholder="Enter name" name="name" class="name"/>
                </div>
            </div>

            <div class="input-box">
                <label>Email</label>
                <input type="email" placeholder="Enter email address"  name="email" class="email"/>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Phone Number</label>
                    <input type="text" placeholder="Enter phone number"  name="phone" class="phone" />
                </div>
                <div class="input-box">
                    <label>Password</label>
                    <input type="password" placeholder="Enter password" name="password" class="password" />
                </div>
            </div>

            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" name="gender" id="check-male" class="gender" name="gender"  value="male" checked>
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" name="gender" id="check-female" class="gender" name="gender"  value="female" >                
                        <label for="check-female">Female</label>
                    </div>
                </div>
            </div>

			<div class="column">
                <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                     $i = 0;
                   foreach($addresses as $key=>$address){
                    $type = "address[$i][type]";
                ?>
                       <div class="input-box">
                             <label><?php echo $address?></label>
                            <input type="hidden"class="type" name="<?php echo $type;?>" value="<?php echo $key; ?>">
                            <input type="text" placeholder="Enter house no " class="house" name="address[<?php echo $i ?>][house]"/>
							<input type="text" placeholder="Enter street address" class="street" name="address[<?php echo $i ?>][street]"/>
                            <input type="text" placeholder="Enter your city" class="city"name="address[<?php echo $i ?>][city]" />
                            <input type="text" placeholder="Enter your state" class="state" name="address[<?php echo $i ?>][state] "/>
                            <input type="text" placeholder="Enter pincode "class="pincode" name="address[<?php echo $i ?>][pincode]"  >
							<input type="text" placeholder="Enter your country " class="country" name="address[<?php echo $i ?>][country]"/>
                       </div>
                    <?php
                    $i++;
                   }
                ?>
			</div>

            <div class="input-box">
                <label>Social media (if any)</label>
                <input type="text" placeholder="Enter Instagram Profile " class="insta"name="instagram"/>
                <input type="text" placeholder="Enter Facebook Profile"class="facebook" name="facebook" />
                <input type="text" placeholder="Enter your Twitter Profile "class="twitter" name="twitter"/>
            </div>

			<div style="text-align:center; margin-top:35px;">
				<button type="submit" name="submit" id="submit" class="btn btn-block btn-info button" >Become a member</button>
			</div>
        </form>

		<div id="response"></div>
    </section>
</div>
<script>
$(document).ready(function(){
	// console.log("submit");
	$("#submit").on('click', function(e){
	// $("button[name='submit']").on('click',function(){
		console.log("yes");
		e.preventDefault();
        var form = new FormData();
         var file = this.files[0];
        var file ='';
        form.append('img', file);
        form.append('name', $('.name').val());
        form.append('email', $('.email').val());
        form.append('password', $('.password').val());
        form.append('phone', $('.phone').val());
        form.append('gender', $('.gender').val());
        form.append('house', $('.house').val());
        form.append('street', $('.street').val());
        form.append('city', $('.city').val());
        form.append('state', $('.state').val());
        form.append('pincode', $('.pincode').val());
        form.append('type', $('.type').val());
        form.append('country', $('.country').val());
		console.log(form.entries()); 
        $.ajax({
			url:'controller/Usercontroller.php',
			type:'POST',
            cache: false,
            contentType: false,
            processData: false,
			data: form,
			success:function(response){
				 console.log('response',response);
                // var parse_data = JSON.parse(response);
				// console.log(parse_data);
				// $('#response').html(parse_data.message);
				
			},
		});
         
		
	});
});
</script>
</body>
<?php
include "layout/footer.php";
?>
</html>