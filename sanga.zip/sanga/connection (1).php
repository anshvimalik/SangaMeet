<?php

trait Connection{
	public $conn;
	function connect(){
		
		$servername ='localhost'; 
		$username ='root';
		$password ='';
		$dbname = 'sangas';
		$conn = new mysqli($servername,$username,$password,$dbname);
		if($conn)
		{
			//echo "yes";
		
		   return $conn;
		}else{
			return false ;
		}		
	}
	// public function query($sql){
	// 	 return mysqli_query($this->conn,$sql);
	// }

}
// class Welcome{
// 	public function  __construct(){
//        use Connection;
// 	}

// }
// $obj=new Welcome();
// $obj->connect();


?>


