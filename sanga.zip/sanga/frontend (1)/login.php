<?php
 include "layout/header.php";
  include "includes/headlinks.php";
?>
<div class="body2">
    <section class="register add">
        <header>Log in</header>
        <form  id="login" class="form" method="POST">
		    
            <div class="input-box">
                <label>Email</label>
                <input type="email" placeholder="Enter email address"  name="email" />
                <label>Password</label>
                <input type="password" placeholder="Enter password"  name="password" />
            </div>
		
			<div style="text-align:center; margin-top:35px;">
				<button type="submit" name="submit" class="btn btn-block btn-info button" >Log in</button>

			</div>
        </form>
		<div id="response"></div>
    </section>
</div>
<?php
 include "layout/footer.php";
?>
<script>
    $(document).ready(function(){
        $('#login').submit(function(e){
            e.preventDefault();
            var loginData = new FormData(this);
           loginData.append('login','true');

            $.ajax({
                url :'controller/Usercontroller.php',
                type :'POST',
                processData: false,
                contentType: false,
                data : loginData,
                success : function(response){
                    console.log(response);
                    window.location.href = 'index.php';
                     var parse_data = JSON.parse(response);
				    console.log(parse_data);
                
                alert(parse_data.message);
                },
            });
        });

    });
</script>    
