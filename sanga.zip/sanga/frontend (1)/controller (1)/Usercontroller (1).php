<?php

	include "C:/xampp/htdocs/meet/connection.php";
	include "C:/xampp/htdocs/meet/vendor/autoload.php";
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	
  class Usercontroller 
{
	use Connection;
	//
	public function  __construct(){
		//$this->dbObj = new Connection();
		//echo "here";
		// $conn = $this->connect();
		// session_start();
	}
	// insert user
	 public  function insertIntoUsers($name,$phone,$email,$password,$gender,$data,$file=null)
	{    
		$instagram =$data['instagram'];
		$facebook=$data['facebook'];
		$twitter=$data['twitter'];
	
		if(empty($name)){
			$response = array(
			"success" => false,
			"message" => "name can't be empty!"
			);
			echo json_encode($response);
			exit;
		}
  	
		$hashedPassword = password_hash($password,PASSWORD_BCRYPT);
		
		// no duplicate email
		$sql = "SELECT * FROM users WHERE email='$email'";

		$conn = $this->connect();
		$result=$conn->query($sql);
		$row_count = mysqli_num_rows($result);
		if ($row_count != 0)
		{
			$response = array(
			"statusCode"=>500,
			"success" => false,
			"message" => "This email id is already registered with us!"
			);
			echo json_encode($response);
			exit;
		}
			
		if(preg_match('/^[7-9][0-9]{9}+$/',$phone) && (filter_var($email, FILTER_VALIDATE_EMAIL)))
		{
			$response = array("statusCode"=>200,"success" => true, "message" => "Invalid Email and Phone format"); 
			echo json_encode($response);
			exit;
		}

		$sql1 = "INSERT INTO users (name,phone,email,password,gender,img) VALUES ('$name','$phone','$email', '$hashedPassword','$gender','$file')";
		$result1 = $conn->query($sql1);
		if ($result1)
			{
				$userId=$this->getUserId($email);
				if($userId)
				{
					$saveAddress = $this->insertIntoAddress($data['address'],$userId);
					{
						if($saveAddress)
						{
                     		$result3= $this-> insertIntoSocials($instagram,$facebook,$twitter,$userId);
					 		if($result3)
					  		{	
								$mail = new PHPMailer(true);	
								$res = $this->mail($email,$mail);
								
								$response = array( "statusCode"=>200,"success" => true, "message" => "Your account has been created succesfully!","emailResponse" => $res); 
								echo json_encode($response);
								exit;
								// header("Location:../index.php");
					 		}
						}
					}
						
				}
			}else{
				$response = array( "statusCode"=>200,"success" => true, "message" => "Something went wrong"); 
				echo json_encode($response);
				exit;
			}
	}

	public function mail($email,$mail)
	{
			

			try {
			//Server settings
			$mail->SMTPDebug = false;                    
			$mail->isSMTP();                                            
			$mail->Host       = 'smtp.gmail.com';                    
			$mail->SMTPAuth   = true; 
			$mail->IsHTML(true);                                  
			$mail->Username   = 'tanyasoni276@gmail.com';                    
			$mail->Password   = 'qgammrizjagwvyfq';                               
			$mail->SMTPSecure = 'tls';           
			$mail->Port       = 587;                                	
			$mail->setFrom('tanyasoni276@gmail.com','meet');
			$mail->addAddress($email, 'new member');    
			$mail->isHTML(true);                               
			$mail->Subject = 'Welcome to Sangameet - Your New User Registration';
			$mail->Body    =' 
				<html>
					<body>
						<p>Dear new user,</p>

						<p>We are delighted to welcome you as a new user to Sangameet! Your registration has been successfully completed, and we are thrilled to have you join our platform.</p>

						<p>Sangameet is a unique online community where individuals from the same city come together to connect, collaborate, and create meaningful offline experiences</p>

						<p>To get started on your journey with Sangameet, please click on the following link to access our website: <a href="xyz.sangameet.com"> xyz.sangameet.com </a></p>

						<p>Here is a quick overview of what you can do on Sangameet:</p>

						<ul>
							<li>Connect with Local Residents</li>
							<li>Plan Personal Meetings </li>
							<li>Collaborate on Projects </li>
							<li>Discover Local Events </li>
						</ul>

						<p>We encourage you to explore Sangameet’s features and start building meaningful connections with fellow residents of your city. If you have any questions, require assistance, or would like to learn more about how to make the most of your Sangameet experience, please do not hesitate to contact our dedicated support team at <a href="mailto:[Support Email Address]">admin@xyz.com</a>.</p>

						<p>Thank you for choosing Sangameet as your platform for connecting with your local community and making a positive impact together. We cannot wait to see the connections and collaborations that will flourish on our platform.</p>

						<p>Welcome to Sangameet!</p>

						<p>Best regards,<br>
						[Your Name]<br>
						[Your Title]<br>
						Sangameet - Connecting Local Communities<br>
						<a href="[Website URL]">[Website URL]</a><br>
						[Contact Information]</p>
					</body>
					</html>
					';


			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
				return 'Message has been sent';
			} catch (Exception $e) {
				return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
	}
	function getUserId($email)
	{
		$sql3="SELECT id FROM users WHERE email = '$email'";
		//$result3 = mysqli_query($obj->connect(), $sql3);
		$result3 = $this->connect()->query($sql3);	
		$num=mysqli_num_rows($result3);
		if($num==1)
		{
			$row=mysqli_fetch_assoc($result3);
			$users_id = $row['id'];
			// echo $users_id;
			
			return $users_id;
		}
	}
	public function insertIntoAddress($addresses,$userId)
	{
       
		$i=1;
		foreach ($addresses as $address)
		{
			 
		    $house = $address["house"];
		    $street = $address["street"];
		    $city = $address["city"];
		    $state = $address["state"];
		    $pincode = $address["pincode"];
		    $country = $address["country"];
		    $type = $address["type"];

			$sql8 = "INSERT INTO addresses( house,street,city,state,pincode,country,type,users_id) VALUES ('$house',' $street',' $city',' $state',' $pincode',' $country',' $type','$userId')";

			$this->connect()->query($sql8);
			$i++;
		}
		return true;	
	}
	public function insertIntoSocials($instagram,$facebook,$twitter,$userId)
	{
		$sql5 = "INSERT INTO socials(instagram,facebook,twitter,users_id) VALUES ('$instagram','$facebook','$twitter','$userId')";
		$result5=$this->connect()->query($sql5);
		if ($result5)
		{
			$response = array( 
			"success" => true,
			"message" => "Your account has been created successfully!"
			);
			// echo json_encode($response);
			return true;
		}	
	}
	// login with approval
	public function logIn($email,$requestPassword)
	{   
		session_start();
		// echo $email;
		// echo $requestPassword;
		$sql="SELECT * FROM users WHERE email='$email'";
		$result=$this->connect()->query($sql);
		$num=mysqli_num_rows($result);
		if($num==1)
		{ 
			$row=mysqli_fetch_assoc($result);
			$hashedpassword=$row['password'];
			$status=$row['status'];	
			if(password_verify($requestPassword,$hashedpassword))
			{
				if($status=="APPROVED"){
				$id = $row['id'];
				$_SESSION['id']=$row['id'];
				$_SESSION['name'] = $row['name'];
				$_SESSION['email'] = $row['email'];
				// header("Location:../index.php");
				// $response = array("status"=>400,"message"=>"login successfull");
				// echo json_encode($response);
				}else
				{
					$response = array( 
						"success" => true,
						"message" =>"LOG-IN failed. An email has been sent to You.Kindly check your email"
					);
					echo json_encode($response); 
					$email= $row['email'];
					$mail = new PHPMailer(true);
					try {
					//Server settings
					$mail->SMTPDebug = false;                     
					$mail->isSMTP();                                            
					$mail->Host       = 'smtp.gmail.com';                    
					$mail->SMTPAuth   = true;                                   
					$mail->Username   = 'tanyasoni276@gmail.com';                    
					$mail->Password   = 'qgammrizjagwvyfq';                               
					$mail->SMTPSecure = 'tls';           
					$mail->Port       = 587;                                	
					$mail->setFrom('tanyasoni276@gmail.com','meet');
					$mail->addAddress($email,'user');    
					$mail->isHTML(true);                               
					$mail->Subject = 'unapproved email';
					$mail->Body    = 'Please contact your admin';
	
					$mail->send();
						//echo 'Message has been sent';
					} catch (Exception $e) {
						//echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
					}
					// header("Location:../index.php");
				}
			}else{

			$response = array( 
			"success" => true,
			"message" =>"Password does not match!"
			);
			echo json_encode($response); 
				// header("Location:../index.php");
			}					
		}
		
	}
	// profile
	public function displayData($user_id)
	{
		$sql_1 = "SELECT *
		FROM users
		JOIN socials ON users.id = socials.users_id
		JOIN addresses ON users.id = addresses.users_id
		WHERE users.id = '$user_id' ";
 		$result_1 = $this->connect()->query($sql_1);
		if($result_1->num_rows > 0)
		{ 
			while($row = $result_1->fetch_assoc())
			{
				$data[]=$row;
			} 
		}
		return $data;
	}
	// update profile
	public function updateAddress($data){
		try {
			//echo"<pre>";print_r($data);
			foreach($data['addr'] as $val){
	         $id = $val['address_id'];
	         $street = $val['street'];
			$house=$val['house'];
			$city=$val['city'];
			$state=$val['state'];
			$pincode=$val['pincode'];
			$country=$val['country'];
			$sql = "UPDATE addresses SET house='$house',city='$city', state='$state',pincode='$pincode',country='$country',  street= '$street' WHERE id= '$id'";
			// $res= $obj1->connect()->query($sql);
			$res= $this->connect()->query($sql);
			}
			return true;
		} catch (\Throwable $th) {
			echo "<pre>";print_r($th);die;
			return false;
		}
	}

	public function updateWithoutProfile($data)
	{
		$name =$_POST['name'];
        $phone =$_POST['phone'];
        $users_id =$_POST['users_id'];
		
		$sql="UPDATE users SET name='$name',phone='$phone' WHERE id= $users_id";
			$res= $this->connect()->query($sql);
			if($res === true)
			{ 
				
			$updateAdd = $this->updateAddress($data);
			// $updateAdd = $this->updateAddress2($data,$obj1,$users_id);
			if($updateAdd){
				echo "Successs";
			
			}
			}


	}
	public function updateWithProfile($data,$file_name)
	{  
		 $name =$_POST['name'];
        $phone =$_POST['phone'];
        $users_id =$_POST['users_id'];
        $email =$_POST['email'];
			$sql="UPDATE users SET name=' $name',phone='$phone',img = '$file_name'WHERE id= '$users_id'";
			
			$res= $this->connect()->query($sql);
			if($res === true)
			{ 
				$updateAdd = $this->updateAddress($data);
				// $updateAdd = $this->updateAddress2($data,$obj1,$users_id);
				if($updateAdd){
					echo "Successs";
					
				}
			}else{
				die("failed");
			}	
		
	}
	public function updateSocials( $data,$users_id)
	{
		$instagram = $_POST['instagram'];
		$twitter = $_POST['twitter'];
		$facebook=  $_POST['facebook'];
	    
		$sql1="UPDATE socials SET instagram='$instagram', twitter=' $twitter', facebook= ' $facebook' WHERE users_id = '$users_id'";
		$res1= $this->connect()->query($sql1);
		if($res1===true)
		{
			echo "Successs";
		}

	}
	// store image
	public function uploadImage($file_name)
	{
		$file_name_array =explode(".", $file_name);
		$extention = end($file_name_array);
		//here to store a new name for a file 
		$new_image_name = 'user_'.time().'.'.$extention;
		if($_FILES['img']['size'] >1000000){
			// $error[]="Sorry, your image is tooo large.Upload less than 1Mb in size";
			$response = array("success" => false, "message" => "Sorry, your image is tooo large.Upload less than 1Mb in size");
			echo json_encode($response);
			return;
		}
		
		if($file_name != "")
		{
			if($extention!="jpg" &&  $extention!="png"  && $extention!="jpeg" && $extention!="gif" &&$extention!="PNG" && $extention!="JPG" &&$extention!="GIF" && $extention!="JPEG" ){
			// $error[]="Sorry ,only JPG,JPEG,PNG & GIF files are allowed";
			$response = array("success" => false, "message" =>"Sorry ,only JPG,JPEG,PNG & GIF files are allowed" );
			echo json_encode($response);
			return;
			}
		}
		return($new_image_name);
	}
	//insert image
	public function insertFile($file_name)
	{
		//echo "test";
		//die;
		echo $sql="INSERT into users (img) VALUES ('$file_name')";
		$result=$this->connect($sql);
		if($result)
		{
			$response = array("message" =>"file inserted");
			 echo json_encode($response);
		}
	}
	public function cityMembers($users_id,$city)
	{
		//$obj=new Connection();
		// $sql = "SELECT *
		// FROM users
		// JOIN socials ON users.id = socials.users_id
		// JOIN addresses ON users.id = addresses.users_id
		// WHERE addresses.city='$city' AND users.id != $users_id AND addresses.type ='r' ORDER BY users.name asc";
		$sql="SELECT addresses.id as addressId, addresses.type as type,addresses.house as house, addresses.street as street,addresses.state as state, addresses.pincode as pincode, users.name as userName,users.id as memberid, users.phone as phone,users.email as email,users.img as img, socials.instagram as instagram, socials.twitter as twitter, socials.facebook as facebook
		FROM addresses
		INNER JOIN users ON addresses.users_id = users.id 
		INNER JOIN socials ON socials.users_id = users.id
		WHERE addresses.city = '$city' AND addresses.type = 'r' AND users.id != $users_id
		 ORDER BY userName asc";
		// $res= $obj->query($sql); 
		$res= $this->connect()->query($sql); 
		// echo"<pre>";print_r($res);
		$num_rows=$res->num_rows;
		// echo $num_rows;
		if($num_rows > 0)
		{
			while($row=$res->fetch_assoc()){
				// echo"<pre>";print_r($row);
				$data[]=$row;	
			}
			return $data;
		}
	}
	public function getCity($users_id)
	{
		//$obj=new Connection();
		// $sql="SELECT city FROM addresses WHERE users_id = '$users_id' AND 'type' ='r'";
		$sql="SELECT city FROM `addresses` WHERE `users_id` = '$users_id' AND type LIKE '%r'";
		// $res = $obj->query($sql);
		$res = $this->connect()->query($sql);
		// echo"<pre>";print_r($res);
		if($res->num_rows == 1)
		{ 
			$num_rows=$res->num_rows;
			// echo $num_rows;
			while($row = $res->fetch_assoc())
			{
				//session_start();
				$_SESSION['city']=$row['city'];
				$data=$_SESSION['city'];
			} 
		}
		return $data;
	}
	public function checkfile($file_name,$email,$users_id,$file_tmp,$obj)
	{
		if($file_name !="")
		{
			$new_image_name=$obj->uploadImage($file_name);
			//echo $new_image_name;
			// die("in");
			// $smtp=mysqli_query( $obj1->connect(),"SELECT img FROM users where email= '$email'");
			$sql="SELECT img FROM users where email= '$email'";
			$result = $this->connect()->query($sql);
			$row = mysqli_fetch_assoc($result);
			$deleteimage=$row['img'];
			$deleteUrl=trim($deleteimage);
			//echo $deleteUrl;
			 unlink("C:/xampp/htdocs/meet/frontend/image/".$deleteUrl);
			move_uploaded_file($file_tmp,"../image/".$new_image_name);
			//echo $new_image_name;
			$data=$_POST;
			$addr=$_POST['addr'];
			$obj->updateWithProfile($data,$new_image_name);
			$obj->updateSocials($data,$users_id);
			 header("Location:../profile.php");

		}else{
			$data=$_POST;
			echo"<pre>";print_r($_POST);
			$obj->updateWithoutProfile($data);
			$obj->updateSocials($data,$users_id);
			 header("Location:../profile.php");
		}

	}
}
// when user will make a member

if(isset($_POST['formAjax']))
{ 
		$obj = new Usercontroller();
		$file_name = $_FILES['img']['name']; 
		$file_tmp = $_FILES['img']['tmp_name'];
		$file_name1 = $obj->uploadImage($file_name);
		move_uploaded_file($file_tmp,"../image/".$file_name1); 
		$data = $_POST;
		$obj->insertIntoUsers($_POST['name'],$_POST['phone'],$_POST['email'],$_POST['password'], $_POST['gender'],$data,$file_name1);
		
}
// when users will login
if(isset($_POST['login'])){
	// echo "here";
	$obj = new Usercontroller();
	$obj->logIn($_POST['email'],$_POST['password']);
	
}
// when users edit their profile
if(isset($_POST['update']))
{
	echo "update";	
	
	//$obj1=new Connection();
	$obj= new Usercontroller();
	$email=$_POST['email'];
	$file_name = $_FILES['img']['name']; 
	//echo $file_name;
	$file_tmp =$_FILES['img']['tmp_name'];
	$users_id =$_POST['users_id'];
	//echo $users_id;
	//if(!isset($error))
	//{
	$obj->checkfile( $file_name,$email,$users_id,$file_tmp,$obj);	
	//}
	
}
?>