
<?php
include "includes/headlinks.php";
include "layout/header.php";
?>
<div class="body2">
    <section class="register add">
        <header>Become our member</header>
        <form  class="form" id="register"  enctype="multipart/form-data">
            <!-- action="controller/Usercontroller.php" method="POST" -->
            <div id="response"></div>
		    <div class="column">
                <div class="input-box">
                    <label class="form-label">Image</label>
                    <input type="file" placeholder="Enter phone number"  name="img"  class=" file "class="form-control" />
                </div>
                <div class="input-box">
                    <label>Name</label>
                    <input type="text" placeholder="Enter name" name="name" class="name"/>
                </div>
            </div>

            <div class="input-box">
                <label>Email</label>
                <input type="email" placeholder="Enter email address"  name="email" class="email"/>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Phone Number</label>
                    <input type="text" placeholder="Enter phone number"  name="phone" class="phone" />
                </div>
                <div class="input-box">
                    <label>Password</label>
                    <input type="password" placeholder="Enter password" name="password" class="password" />
                </div>
            </div>

            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" name="gender" id="check-male" class="gender" name="gender"  value="male" checked>
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" name="gender" id="check-female" class="gender" name="gender"  value="female" >                
                        <label for="check-female">Female</label>
                    </div>
                </div>
            </div>

			<div class="column">
                <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                     $i = 0;
                   foreach($addresses as $key=>$address){
                    $type = "address[$i][type]";
                ?>
                       <div class="input-box">
                             <label><?php echo $address?></label>
                            <input type="hidden"class="type_<?php echo $i; ?>" name="address[<?php echo $i ?>][type]" value="<?php echo $key; ?>">
                            <input type="text" placeholder="Enter house no " class="house_<?php echo $i; ?>" name="address[<?php echo $i ?>][house]"/>
							<input type="text" placeholder="Enter street address" class="street_<?php echo $i; ?>" name="address[<?php echo $i ?>][street]"/>
                            <input type="text" placeholder="Enter your city" class="city_<?php echo $i; ?>"name="address[<?php echo $i ?>][city]" />
                            <input type="text" placeholder="Enter your state" class="state_<?php echo $i; ?>" name="address[<?php echo $i ?>][state] "/>
                            <input type="text" placeholder="Enter pincode "class="pincode_<?php echo $i; ?>" name="address[<?php echo $i ?>][pincode]"  >
							<input type="text" placeholder="Enter your country " class="country_<?php echo $i; ?>" name="address[<?php echo $i ?>][country]"/>
                       </div>
                    <?php
                    $i++;
                   }
                ?>
			</div>

            <div class="input-box">
                <label>Social media (if any)</label>
                <input type="text" placeholder="Enter Instagram Profile " class="insta"name="instagram"/>
                <input type="text" placeholder="Enter Facebook Profile"class="facebook" name="facebook" />
                <input type="text" placeholder="Enter your Twitter Profile "class="twitter" name="twitter"/>
            </div>

			<div style="text-align:center; margin-top:35px;">
				<button type="submit" name="submit" id="submit" class="btn btn-block btn-info button" >Become a member</button>
			</div>
        </form>

    </section>
</div>


</body>
<?php
include "layout/footer.php";
?>
<script>
$(document).ready(function(){
    $('#register').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        formData.append('formAjax','true');
        
        $.ajax({
			url:'controller/Usercontroller.php',
			type:'POST',
            // cache: false,
            contentType: false,
            processData: false,
			data:formData,
			success:function(response){
				console.log(response);
                
                var parse_data = JSON.parse(response);
				console.log(parse_data);
                
                alert(parse_data.message);
                
				// $('#response').html(parse_data.message);
				// $('#response').show(parse_data.message);
                // $("#response").delay(5000).fadeOut();
	
			},
		});

	});
});
</script>
