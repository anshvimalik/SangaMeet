<?php
  include "includes/headlinks.php";
  session_start();
  include "layout/header.php";
  include "controller/Usercontroller.php";
   if (!isset($_SESSION["id"])) {
       header("location: index.php");
       die();
   }
   $user_id = $_SESSION["id"]; 
   $obj = new Usercontroller();
   $obj->displayData($user_id);
   $data=$obj->displayData($user_id);
  //  echo"<pre>";print_r($data);
  
?>
<body>
   <div class="container">
    <div class="accordion " id="accordionPanelsStayOpenExample">
        <div class="accordion-item ">
          <h2 class="accordion-header ">
              <button class="accordion-button li" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
              Personal Details
              </button>
          </h2>
          <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show">
              <div class="accordion-body">
                <form action="controller/UserController.php" method="POST" enctype="multipart/form-data">
                    <?php 
                      if($data)
                      {
                       $file_name = $data[0]['img'];
                        //echo $file_name;
                        if($file_name == NULL)
                        {
                          //  echo'<img src="logo/profile.jpeg">';
                         }else{
                          $imgUrl = "image/".trim($file_name);
                        //  echo $imgUrl;
                    ?>
                    <?php
                      } 
                      $filterData = [];
                      $s = 0;
                      foreach( $data as $rows)
                      {      
                      // echo $rows['house'];
                      $filterData[$s]['house'] = $rows['house'];
                      $filterData[$s]['street'] = $rows['street'];
                      $filterData[$s]['city'] = $rows['city'];
                      $filterData[$s]['state'] = $rows['state'];
                      $filterData[$s]['pincode'] = $rows['pincode'];
                      $filterData[$s]['country'] = $rows['country'];
                      $filterData[$s]['id'] = $rows['id'];
                      $s++;
                      }
                    ?>


                    <div class="d-flex justify-content-center  align-items-center dprofile">
                      <div class="imgprofile">
                        <img class="profile" src="<?php echo $imgUrl; ?>">
                      </div>
                      <div><h4><?php { echo $rows['name']; } ?></h4></div>
                    </div> 


                    <div class=" row justify-content-center">
                      <div class="col-12 ">
                        <!-- <div class="justify-content-start padding-right"><img class="profile" src="<?php echo $imgUrl; ?>"></div> -->
                        <label for="exampleFormControlInput1" class="form-label">Profile</label>
                        <input type="file" class="form-control" id="exampleFormControlInput1" name="img" class="img">
                        <input type="hidden" value="<?php {echo $rows['users_id'] ; }?>" name="users_id" /> 
                      </div>
                    </div>
                    
                    <div class="row my-2">

                      <div class="col-4">
                        <label >Name</label>
                        <input type="text" class="form-control" placeholder="username" value="<?php { echo $rows['name']; } ?>" name="name" >
                      </div>

                      <div class="col-4">
                      <label for="exampleFormControlInput3" class="form-label ">Email</label>
                      <input type="email" class="form-control" id="exampleFormControlInput3" placeholder="name@example.com"     value="<?php if(isset($rows['email'])) { echo $rows['email']; } ?>"  name="email" readonly>
                      </div>

                      <div class="col-4">
                      <label for="exampleFormControlInput4" class="form-label ">PhoneNumber</label>
                      <input type="text" class="form-control" id="exampleFormControlInput4" placeholder="enter the phone number"  value="<?php if(isset($rows['phone'])) { echo $rows['phone']; } ?>" name="phone" >
                      </div> 

                    </div>

                    <div class="row">

                      <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                              $i = 0;
                              foreach ($addresses as $key=>$address) {
                              $type = "addr[$i][type]";
                      ?>

                      <div class="col-6">
                            
                            <!-- <div class="form-label"> -->
                              <label class="form-label"><?php echo $address ?></label>
                            <!-- </div> -->
                          
                            <div >
                            
                              <input type="hidden" class="form-control" name="<?php echo $type; ?>" value="<?php echo $key; ?>">
                              <input type="hidden" class="form-control" name="addr[<?php echo $i ?>][address_id]" value="<?php if(isset($filterData[$i]['id'])){echo $filterData[$i]['id'];}?>">


                              <input type="text" class="form-control" placeholder="Enter house no "  name="addr[<?php echo $i ?>][house]" value="<?php if(isset($filterData[$i]['house'])){echo $filterData[$i]['house'];}?>"/>
                              <input type="text" class="form-control" placeholder="Enter street address"  name="addr[<?php echo $i ?>][street]" value="<?php echo $filterData[$i]['street'];?>"/>
                              <input type="text" class="form-control" placeholder="Enter your city" name="addr[<?php echo $i ?>][city]" value="<?php echo $filterData[$i]['city'];?>"/>
                              <input type="text" class="form-control" placeholder="Enter your state"  name="addr[<?php echo $i ?>][state]"value="<?php echo $filterData[$i]['state'];?>"/> 
                              <input type="text"  class="form-control"placeholder="Enter pincode " name="addr[<?php echo $i ?>][pincode]" value="<?php echo $filterData[$i]['pincode'];?>" >
                              <input type="text"  class="form-control"placeholder="Enter your country " name="addr[<?php echo $i ?>][country]"value="<?php echo $filterData[$i]['country'];?>"/>
                            
                            </div>
                          
                      </div>
                      <?php  
                              $i++;
                              }
                      ?>
                    </div>
                    <div class="row">
                      <div class="col-12 mt-3 mb-1">
                        <label>Social media (if any)</label>
                      </div>
                      <div class="col-sm-4 col-12">
                                 <input type="text" class="form-control" placeholder="Enter Instagram Profile " name="instagram"  value="<?php if(isset($rows['instagram'])) {  echo $rows['instagram']; } ?>"  >
                                
                       </div>
                      <div class="col-sm-4 col-12">
                                
                                 <input type="text" class="form-control" placeholder="Enter Facebook Profile"name="facebook"  value="<?php echo $rows['facebook'] ;?>">
                                 
                       </div>
                      <div class="col-sm-4 col-12">
                                 
                                 <input type="text" class="form-control" placeholder="Enter your Twitter Profile " name="twitter" value="<?php echo $rows['twitter'] ;?>">
                       </div>
                    </div>
                    
                    <div class="text-center my-3 ">
                            <button type="submit" name="update" class="btn btn-block btn-primary sign" >Confirm</button>
                    </div>
                  <?php    
                      }
                    ?> 
                </form>
               </div>
          </div>
        </div>
        <!-- <div class="accordion-item">
          <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
              City Members
              </button>
          </h2>
          <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse">
              <div class="accordion-body">
                <div class="container">
                 
                </div>

              </div>
          </div>
        </div>
        <div class="accordion-item">
          <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
              Requests
              </button>
          </h2>
          <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse">
              <div class="accordion-body">
              </div>
          </div>
        </div>  -->
    </div>
  </div>
   <?php
      include "layout/footer.php";
    ?>
</body>
 </html>