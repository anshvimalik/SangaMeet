<?php
session_start();
    include "layout/header.php";
     include "includes/headlinks.php";
     include "../backend/controller/Usercontroller.php";
?>
<?php
if (isset($_GET['reportid'])) 
{
  $email = $_GET['reportid'];
}
?>


<div class="body2">
     <section class="register add">
         <header>Report</header>
        <form action="../backend/controller/Usercontroller.php" method="POST" class="form"  enctype="multipart/form-data" >
           
                <label class="form-label">Screenshot</label>
                 <input type="file" class="form-control" placeholder="name@example.com"  name="files[]" class="img" multiple="multiple">
                 <input type="hidden" name="reportid" value="<?php echo $email;?>">

                <label class="form-label">Describe Reason</label>
                <textarea name="description" id="" cols="30" rows="10"  class="form-control" ></textarea>
                <div style="text-align:center; margin-top:35px;">
                  <button type="submit" name="report" class="btn btn-block btn-info button" >Confirm</button>
                </div>
         </form>
 		<div id="response"></div>
     </section>
 </div>
<?php
 include "layout/footer.php";
?>