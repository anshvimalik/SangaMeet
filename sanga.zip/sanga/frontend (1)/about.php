
<?php
session_start();
 include "layout/header.php";
 include "includes/headlinks.php";
 ?>

<div class="about-container">
    <h1 class="text-white pb-3">About Us</h1>
</div>

<div class="container mt-5">
    <div class="row">
        <div  class ="col-md-6 ">
              <img  src="logo/SangaMeet.png " style="height:200px;" >
             <h3>What is SangaMeet</h3>
				<p>Sangameet is a unique online community where individuals from the same city come together to connect, collaborate, and create meaningful offline experiences. Our platform is designed to help you get to know people in your city, plan personal meetings, and engage in productive activities such as organizing events, workshops, and more.</p>
        </div>
        <div class="col-md-6">
            <div class="accordion accordion-flush" id="accordionFlushExample">
                <div class="accordion-item mb-2 ">
                    <h2 class="accordion-header" id="flush-headingOne">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                      About Us
                    </button>
                    </h2>
                    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">

At SangaMEET, we are passionate about turning online connections into real-world action. We believe that when people come together, great things can happen. Our mission is to facilitate meaningful connections among local residents who are eager to meet offline and collaborate on productive projects.</div>
                    </div>
                </div>
                <div class="accordion-item mb-2">
                    <h2 class="accordion-header" id="flush-headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                       Our Roots
                    </button>
                    </h2>
                    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">SangaMEET was founded by a group of individuals who shared a common vision: to create a platform that brings neighbors together to work on projects that benefit our community. We understand the power of collaboration, and we are committed to helping our local area flourish through collective effort.</div>
                    </div>
                </div>
                <div class="accordion-item mb-2">
                    <h2 class="accordion-header" id="flush-headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                      What We Offer
                    </button>
                    </h2>
                    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body ">
                        <li  class="mb-2 aboutli"  >Connect with Local Residents :</li>
                         <p>Discover and connect with people who reside in your city and share your interests.</p>
                        <li class="mb-2 aboutli"  >Plan Personal Meetings :</li>
                       <p>Easily organize meetups, coffee chats, or collaborative sessions with other members to build strong local connections.</p>
                        <li class="mb-2 aboutli"  >Collaborate on Projects :</li>
                        <p>  Find like-minded individuals to work on projects, events, or community initiatives that matter to you.</p>
                        <li  class="mb-2 aboutli" >Discover Local Events :</li>
                       <p>Stay updated on upcoming events, workshops, and gatherings in your city, and even contribute to their planning..</p> </div>
                    </div>
                </div>
                <div class="accordion-item mb-2">
                    <h2 class="accordion-header" id="flush-headingFour">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                      OUR values
                    </button>
                    </h2>
                    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">Community, Authenticity, Loyalty, Friendship, Empathy, Fun!</div>
                    </div>
                </div>
             </div>
         </div>
    </div>

</div>

 <?php
 include "layout/footer.php";
?>