<?php
 session_start();
 include "includes/headlinks.php";
 include "layout/header.php";
?>
<?php 
include '../backend/controller/Usercontroller.php';
$userObj = new Usercontroller();
$sliders = $userObj->selectSliderStatus();
?>
<style>

	.slick-prev {
		left: 100px;
		/* background: red; to notice it, is white */
		z-index: 1;
	}
	
	.slick-next {
		right: 100px;
		/* //background: red; to notice it, is white */
	}
	
	.slick-dots li.slick-active button:before {
		opacity: 100;
		color: white;
	}
	
	.slick-dots {
		bottom: 5px;
	}
</style>
<!-- crousel start -->
<section>
	<div class="banner-slider " style="height:25rem">
		<?php 	
				$i=0;
				foreach ($sliders as $slider){
				$filename = $slider['img'];
		?>
		<div class="inner"> 
				<img class="sliderimg " src="image/<?php  echo $filename ?>" class="d-block w-100" >
				<div class="carousel-caption d-none d-md-block mb-5 mb-5">
					<h5><?php echo $slider['title'] ?></h5>
					<p><?php echo $slider['description']?></p>
				</div>
		</div>
		<?php  
		$i++;
		} 
		?>
	</div>
</section>
<!-- crousel ends-->
<!-- about us -->
<section class="hero ">
	<div class="heading">
		<h1>About Us</h1>
	</div>
	<div class="about mb-5">
			<div class="hero-content">
				<h3>What is SangaMeet</h3>
				<p>"Welcome to SangaMeet, the online destination where friends from all walks of life come together to create unforgettable memories that will last a lifetime."</p>
				<button class="sign btn btn-1"><a href="about.php">Learn More</a>
				</button>
			</div>
			<div class="hero-image">
				<img src="logo/8.jpeg">
			</div>
	</div>
	</div>
</section>
<!-- about us end -->
<script>
	$('.banner-slider').slick({
  		slidesToShow: 1,
  		slidesToScroll: 1,
  		arrows: true,
  		fade: true,
  		dots:true,
   		prevArrow:"<img class='a-left control-c prev slick-prev' src='../images/shoe_story/arrow-left.png'>",
      	nextArrow:"<img class='a-right control-c next slick-next' src='../images/shoe_story/arrow-right.png'>"
	});
</script>
<?php
include "layout/footer.php";
?>	
</body>
</html>